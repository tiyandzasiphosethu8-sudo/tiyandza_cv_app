package com.example.tiyandzaz_cv_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
