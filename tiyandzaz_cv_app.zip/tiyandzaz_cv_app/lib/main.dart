import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home:MyCVApp()));

}
class  MyCVApp extends StatelessWidget {
  const MyCVApp({super.key});

@override
  Widget build(BuildContext context) {
  return MaterialApp(
    title: 'MY CV App',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
        primaryColor: Colors.lightBlueAccent,
    ),
    home: const CVScreen(),
  );
}
}
class CVScreen extends StatelessWidget {
  const CVScreen({super.key});

  final String name = "Tiyandza Siphosethu Mhlanga";
  final String title = "Data analyst";
  final String boi = "young experienced data analyst who is passionate about making senseless data communicate to users";
  final String email = "siphosethutiyandza000@gmail.com";
  final String phone = "268 79123421";
  final String linkedin = "https://linkedin.com/in/Siphosethu";
  final String github = "https://github.com/Siphosethu";
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('MY CV app')),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  const CircleAvatar(
                    radius: 50,
                    backgroundColor: Colors.green,
                    child: Icon(Icons.person, size: 40, color: Colors.white),
                  ),
                  const SizedBox(height: 10),
                  Text(name, style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.bold)),
                  Text(name,
                      style: const TextStyle(fontSize: 16, color: Colors.blue)),
                  const SizedBox(height: 8),
                  Text(bio, textAlign: TextAlign.center),
                ],
              ),
            ),
            _title("Contact"),
            Card(
              child: Column(
                children: [
                  ListTile(leading: const Icon(Icons.email),
                      title: Text(email),
                      onTap: () => _openLink("mailto:$email"),
                  ),
                  ListTile(
                      leading: const Icon(Icons.phone),
                      title: Text(phone),
                      onTap: () => _openLink("tel:$phone"),
                  ),
                  ListTile(
                      leading: const Icon(Icons.link),
                      title: const Text("linkedIn"),
                      onTap: () => _openLink(linkedin),
                  ),
                  ListTile(
                      leading: const Icon(Icons.code),
                      title: const Text("github"),
                      onTap: () => _openLink(github),
                  ),
                ],

              ),

            ),
            _title("Skills"),
            const Wrap(
              spacing: 8,
              children: [
                Chip(label: Text("Data Analysis")),
                Chip(label: Text("SQL")),
                Chip(label: Text("python")),
                Chip(label: Text("excel")),
                Chip(label: Text("Flutter")),
                Chip(label: Text("communication")),
              ],
            ),
            _title("Experience"),
            _card(
                "Data Analyst Intern,CONCO company|2026,Analyzed datasets, create dashboards in power BI and generated insights for business decisions"),

            _card("Freelance Data Projects, 2024-2025,built excel reports and data visualization for small busissnesses"),
            _title("Education"),
            _card("BSC COMPUTER Science,UNESWA|2022-2026,Relevent: Data Structures,Statistics,Database Syaytems"),
          ],
        ),
      ),

    );
  }
  Widget _title(String t)=> Padding(
    padding: const EdgeInsets.only(top:20, bottom:8),
      child: Text (t, style: const TextStyle(fontSize: 18,color: Colors.blue)),
  );
Widget _card(String t1 ,String t2,String t3) => Card(
  child:ListTile(
    title: Text(t1 , style: const TextStyle(fontWeight: FontWeight.bold)),
    subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start,children:[Text(t2), const SizedBox(height:4), Text(t3)]),

  ),
);
}